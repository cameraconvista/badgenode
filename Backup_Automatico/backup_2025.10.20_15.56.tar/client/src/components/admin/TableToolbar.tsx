// Componente rimosso - filtri eliminati come richiesto
