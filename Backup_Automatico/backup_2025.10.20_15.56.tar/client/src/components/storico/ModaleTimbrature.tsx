// ModaleTimbrature facade - maintains same API for backward compatibility
export { default } from './ModaleTimbrature/ModaleTimbrature';
export type { ModaleTimbratureProps, FormData } from './ModaleTimbrature/types';
