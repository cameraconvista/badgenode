import { Router } from 'express';
import { TimbratureExportService } from '../services/timbratureExport.service';
import * as XLSX from 'xlsx';

const router = Router();

router.get('/timbrature.xlsx', async (_req, res) => {
  try {
    const buf = await TimbratureExportService.buildWorkbookBuffer();
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename="badgenode_export_${new Date().toISOString().split('T')[0]}.xlsx"`);
    res.setHeader('Content-Length', Buffer.byteLength(buf));
    return res.status(200).end(buf);
  } catch (error: any) {
    console.error('Errore export timbrature:', error?.message || error);
    res
      .status(500)
      .json({ code: 'EXPORT_ERROR', message: error?.message || 'Errore export timbrature' });
  }
});

// Self-test workbook (no DB) per diagnosi rapida
router.get('/_selftest.xlsx', (_req, res) => {
  const wb = XLSX.utils.book_new();
  const ws = XLSX.utils.aoa_to_sheet([["OK", "SelfTest"], [new Date().toISOString()]]);
  XLSX.utils.book_append_sheet(wb, ws, 'Test');
  const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
  res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
  res.setHeader('Content-Disposition', 'attachment; filename="selftest.xlsx"');
  res.setHeader('Content-Length', Buffer.byteLength(buf));
  return res.status(200).end(buf);
});

export default router;
