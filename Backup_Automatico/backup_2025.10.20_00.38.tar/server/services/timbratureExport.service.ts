import * as XLSX from 'xlsx';
import { supabaseAdmin } from '../lib/supabaseAdmin';

export class TimbratureExportService {
  static async fetchDistinctPins(): Promise<number[]> {
    if (!supabaseAdmin) throw new Error('Supabase admin non disponibile');

    const { data, error } = await supabaseAdmin
      .from('timbrature')
      .select('pin')
      .order('pin', { ascending: true });

    if (error) throw new Error(error.message);
    const uniquePins = Array.from(new Set((data || []).map((r: any) => r.pin))).filter((p) => Number.isInteger(p));
    return uniquePins as number[];
  }

  static async fetchTimbratureForPin(pin: number): Promise<any[]> {
    if (!supabaseAdmin) throw new Error('Supabase admin non disponibile');

    const { data, error } = await supabaseAdmin
      .from('timbrature')
      .select('data_locale, ora_locale, tipo, giorno_logico, created_at')
      .eq('pin', pin)
      .order('giorno_logico', { ascending: true })
      .order('ts_order', { ascending: true });

    if (error) throw new Error(error.message);
    return data || [];
  }

  static async generateWorkbook() {
    const wb = XLSX.utils.book_new();
    (wb as any).Props = { Creator: 'BadgeNode Export', CreatedDate: new Date() };

    const pins = await this.fetchDistinctPins();

    // Precarica mappa PIN -> { nome, cognome }
    const utentiMap = await this.fetchUtentiMap(pins);

    // Helper: sanitizza nome foglio Excel
    const sanitizeSheetName = (name: string) => {
      // Excel non accetta: : * ? / \ [ ] e limita a 31 char
      const invalid = /[:*?/\\\[\]]/g;
      const cleaned = (name || '').replace(invalid, ' ').trim().replace(/\s+/g, ' ');
      return cleaned || '';
    };

    // Helper: genera nome con fallback e unicità
    const usedNames = new Set<string>();
    const makeUniqueName = (base: string, pin: number) => {
      let candidate = base;
      if (!candidate) candidate = `PIN_${String(pin).padStart(2, '0')}`;
      // Rispetta limite 31 caratteri
      candidate = candidate.slice(0, 31);
      if (!usedNames.has(candidate)) {
        usedNames.add(candidate);
        return candidate;
      }
      // Conflitto: aggiungi suffisso con PIN
      const suffix = ` (PIN_${String(pin).padStart(2, '0')})`;
      const maxBaseLen = Math.max(0, 31 - suffix.length);
      const truncated = candidate.slice(0, maxBaseLen);
      const withSuffix = `${truncated}${suffix}`;
      usedNames.add(withSuffix);
      return withSuffix;
    };

    for (const pin of pins) {
      try {
        const records = await this.fetchTimbratureForPin(pin);
        const normalized = (records || []).map((r) => ({
          Data: r.data_locale,
          Ora: r.ora_locale,
          Tipo: r.tipo,
          'Giorno Logico': r.giorno_logico,
          'Creato Il': r.created_at,
        }));
        const ws = XLSX.utils.json_to_sheet(
          normalized.length ? normalized : [{ Nota: '— Nessuna timbratura —' }]
        );

        // Nome cognome se disponibili, altrimenti fallback PIN
        const ut = utentiMap.get(pin);
        const baseName = ut && ut.nome && ut.cognome ? `${ut.cognome} ${ut.nome}` : `PIN_${String(pin).padStart(2, '0')}`;
        const safeBase = sanitizeSheetName(baseName);
        const sheetName = makeUniqueName(safeBase, pin);
        XLSX.utils.book_append_sheet(wb, ws, sheetName);
      } catch (e) {
        const ws = XLSX.utils.aoa_to_sheet([[`ERRORE: ${(e as Error).message}`]]);
        const fallback = `PIN_${String(pin).padStart(2, '0')}`.slice(0, 31);
        const name = makeUniqueName(fallback, pin);
        XLSX.utils.book_append_sheet(wb, ws, name);
      }
    }

    return wb;
  }

  static async buildWorkbookBuffer(): Promise<Buffer> {
    const wb = await this.generateWorkbook();
    // SheetJS in Node: write buffer
    const buf = XLSX.write(wb, { type: 'buffer', bookType: 'xlsx' }) as Buffer;
    return buf;
  }

  private static async fetchUtentiMap(pins: number[]): Promise<Map<number, { nome?: string | null; cognome?: string | null }>> {
    const m = new Map<number, { nome?: string | null; cognome?: string | null }>();
    if (!pins.length) return m;
    if (!supabaseAdmin) return m;
    const { data, error } = await supabaseAdmin
      .from('utenti')
      .select('pin,nome,cognome')
      .in('pin', pins);
    if (error) return m;
    const rows = (data || []) as Array<{ pin: number; nome?: string | null; cognome?: string | null }>;
    for (const row of rows) {
      const p = Number(row.pin);
      if (Number.isFinite(p)) m.set(p, { nome: row.nome ?? null, cognome: row.cognome ?? null });
    }
    return m;
  }
}
