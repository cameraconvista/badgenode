import { useState, useEffect, useCallback } from 'react';
import { getApiBaseUrl } from '@/lib/api';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { ArrowLeft, Archive, Plus, Download } from 'lucide-react';
import ArchivioTable from '@/components/admin/ArchivioTable';
import ModaleNuovoDipendente from '@/components/admin/ModaleNuovoDipendente';
import ModaleModificaDipendente from '@/components/admin/ModaleModificaDipendente';
import ModaleEliminaDipendente from '@/components/admin/ModaleEliminaDipendente';
import { UtentiService, Utente, UtenteInput } from '@/services/utenti.service';
import { useAuth } from '@/contexts/AuthContext';
import { subscribeTimbrature } from '@/lib/realtime';
import { invalidateUtenti, debounce } from '@/state/timbrature.cache';

export default function ArchivioDipendenti() {
  const [, setLocation] = useLocation();
  const [utenti, setUtenti] = useState<Utente[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [showModaleModifica, setShowModaleModifica] = useState(false);
  const [showModaleNuovo, setShowModaleNuovo] = useState(false);
  const [showModaleElimina, setShowModaleElimina] = useState(false);
  const [utenteSelezionato, setUtenteSelezionato] = useState<Utente | null>(null);
  const [isEliminaLoading, setIsEliminaLoading] = useState(false);
  const { isAdmin } = useAuth();
  useEffect(() => {
    if (!isAdmin) return;
    const debouncedInvalidate = debounce(() => {
      invalidateUtenti();
      loadUtenti();
    }, 250);
    const unsubscribe = subscribeTimbrature({
      onChange: (_payload: unknown) => {
        void _payload;
        debouncedInvalidate();
      },
    });
    return () => unsubscribe();
  }, [isAdmin]);
  useEffect(() => {
    loadUtenti();
  }, []);
  const loadUtenti = async () => {
    setIsLoading(true);
    try {
      const data = await UtentiService.getUtenti();
      setUtenti(data);
    } catch (_error) {
      void _error;
    } finally {
      setIsLoading(false);
    }
  };
  const handleStorico = (pin: number) => {
    setLocation(`/storico-timbrature/${pin}`);
  };
  const _onEditClick: (_id: number) => void = (_id) => { void _id;
    setLocation(`/storico-timbrature/${_id}`);
  };
  const handleModifica = (utente: Utente) => {
    setUtenteSelezionato(utente);
    setShowModaleModifica(true);
  };
  const handleArchivia = async (_id: string) => { void _id; };
  const handleEliminaClick = (utente: Utente) => {
    setUtenteSelezionato(utente);
    setShowModaleElimina(true);
  };
  const handleConfermaElimina = async () => {
    if (!utenteSelezionato) return;
    setIsEliminaLoading(true);
    try {
      await UtentiService.deleteUtente(utenteSelezionato.pin);
      await loadUtenti();
      setShowModaleElimina(false);
      setUtenteSelezionato(null);
    } catch (error) {
      console.error('Errore eliminazione dipendente:', error);
      // L'errore viene gestito dal modale che rimane aperto
    } finally {
      setIsEliminaLoading(false);
    }
  };
  const handleSalvaModifica = async (datiUtente: UtenteInput) => {
    if (!utenteSelezionato) return;
    try {
      await UtentiService.updateUtente(utenteSelezionato.pin, datiUtente);
      await loadUtenti();
      setShowModaleModifica(false);
      setUtenteSelezionato(null);
    } catch (error) {
      throw error;
    }
  };
  const handleSalvaNuovo = async (data: UtenteInput) => {
    try {
      await UtentiService.createUtente(data);
      await loadUtenti();
      setShowModaleNuovo(false);
    } catch (error) {
      throw error;
    }
  };
  const handleBackToLogin = () => setLocation('/');
  const _handleRealtimeChange = useCallback((_payload: unknown) => { void _payload; }, []);
  const handleExDipendenti = () => {
    // TODO(BUSINESS): Implementare navigazione a Ex-Dipendenti
  };

  const handleEsportaTutto = async () => {
    const base = getApiBaseUrl();
    const url = `${base}/api/export/timbrature.xlsx`;
    console.log('EXPORT URL ->', url);
    try {
      const res = await fetch(url, {
        method: 'GET',
        headers: {
          Accept:
            'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/octet-stream',
        },
        credentials: 'include',
      });
      const ct = res.headers.get('content-type') || '';
      console.log('Content-Type:', ct);
      if (!res.ok) {
        const errText = await res.text().catch(() => '');
        console.error('[EXPORT] HTTP error', res.status, errText.slice(0, 500));
        alert(`Errore export (${res.status}). Vedi console per dettagli.`);
        return;
      }
      if (
        !ct.includes('application/vnd.openxmlformats-officedocument.spreadsheetml.sheet') &&
        !ct.includes('application/octet-stream')
      ) {
        const maybeHtml = await res.text().catch(() => '');
        console.error('[EXPORT] Risposta non-xlsx (probabile HTML):\n', maybeHtml.slice(0, 800));
        alert('Export fallito: ricevuto contenuto non XLSX. Controlla VITE_API_BASE_URL e l\u2019endpoint server.');
        return;
      }
      const blob = await res.blob();
      const href = URL.createObjectURL(blob);
      const a = document.createElement('a');

      const today = new Date();
      const yyyy = today.getFullYear();
      const mm = String(today.getMonth() + 1).padStart(2, '0');
      const dd = String(today.getDate()).padStart(2, '0');
      const filename = `badgenode_timbrature_${yyyy}-${mm}-${dd}.xlsx`;

      a.href = href;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(href);
      console.log('[EXPORT] Download OK:', filename);
    } catch (err) {
      console.error('[EXPORT] Exception', err);
      alert('Export fallito per errore di rete. Vedi console.');
    }
  };

  return (
    <div
      className="h-screen flex items-center justify-center p-4 overflow-hidden fixed inset-0"
      style={{
        background: 'radial-gradient(ellipse at center, #2d1b3d 0%, #1a0f2e 50%, #0f0a1a 100%)',
        backgroundAttachment: 'fixed',
      }}
    >
      <div className="w-full max-w-[1120px] flex items-center justify-center h-full">
        <div
          className="rounded-3xl p-4 shadow-2xl border-2 w-full h-[90vh] overflow-hidden relative flex flex-col"
          style={{
            backgroundColor: '#2b0048',
            borderColor: 'rgba(231, 116, 240, 0.6)',
            boxShadow: '0 0 20px rgba(231, 116, 240, 0.3), inset 0 0 20px rgba(231, 116, 240, 0.1)',
          }}
        >
          {/* Header con logo centrato */}
          <div className="flex justify-center mb-4">
            <img src="/logo2_app.png" alt="BADGENODE" className="h-10 w-auto" />
          </div>
          <div className="text-center mb-4">
            <h1 className="text-2xl font-bold text-white mb-2">Archivio Dipendenti</h1>
            <p className="text-yellow-300 text-base md:text-lg font-medium">
              {utenti.length} dipendenti attivi
            </p>
          </div>
          <div className="flex-1 overflow-hidden mb-4">
            <ArchivioTable
              utenti={utenti}
              isLoading={isLoading}
              onStorico={handleStorico}
              onModifica={handleModifica}
              onArchivia={handleArchivia}
              onElimina={handleEliminaClick}
            />
          </div>
          <div className="flex flex-col sm:flex-row gap-2 items-center justify-between pt-3 border-t border-gray-600">
            <Button
              variant="outline"
              onClick={handleBackToLogin}
              className="flex items-center gap-2 bg-white border-2 border-violet-600 text-violet-600 hover:bg-violet-50 hover:shadow-md transition-all"
            >
              <ArrowLeft className="w-4 h-4" />
              Badge
            </Button>
            <div className="flex gap-2">
              <Button
                variant="outline"
                onClick={handleEsportaTutto}
                className="flex items-center gap-2 bg-white border-2 border-violet-600 text-blue-600 hover:text-blue-500 hover:bg-violet-50 hover:shadow-md transition-all"
              >
                <Download className="w-4 h-4 text-current" />
                Esporta Tutto
              </Button>
              <Button
                variant="outline"
                onClick={handleExDipendenti}
                className="flex items-center gap-2 bg-white border-2 border-violet-600 text-yellow-700 hover:text-yellow-600 hover:bg-violet-50 hover:shadow-md transition-all"
              >
                <Archive className="w-4 h-4 text-current" />
                Ex-Dipendenti
              </Button>
              <Button
                onClick={() => setShowModaleNuovo(true)}
                className="flex items-center gap-2 bg-violet-600 hover:bg-violet-700 text-white"
              >
                <Plus className="w-4 h-4" />
                Aggiungi
              </Button>
            </div>
          </div>
        </div>
      </div>

      <ModaleModificaDipendente
        isOpen={showModaleModifica}
        onClose={() => {
          setShowModaleModifica(false);
          setUtenteSelezionato(null);
        }}
        utente={utenteSelezionato}
        onSave={handleSalvaModifica}
      />
      <ModaleNuovoDipendente
        isOpen={showModaleNuovo}
        onClose={() => setShowModaleNuovo(false)}
        onSave={handleSalvaNuovo}
      />
      <ModaleEliminaDipendente
        isOpen={showModaleElimina}
        onClose={() => {
          setShowModaleElimina(false);
          setUtenteSelezionato(null);
        }}
        utente={utenteSelezionato}
        onConfirm={handleConfermaElimina}
        isLoading={isEliminaLoading}
      />
    </div>
  );
}
