export default function App() {
  return (
    <div style={{ 
      background: '#0f0a1a', 
      color: 'white', 
      minHeight: '100vh', 
      padding: '20px',
      fontFamily: 'Arial'
    }}>
      <h1>BadgeNode - Test Simple</h1>
      <p>Se vedi questo testo, React funziona!</p>
    </div>
  );
}
