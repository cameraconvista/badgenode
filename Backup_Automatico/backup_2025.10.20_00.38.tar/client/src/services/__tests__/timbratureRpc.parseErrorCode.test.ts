import { describe, it, expect } from 'vitest'
import { parseErrorCode } from '../timbratureRpc'

describe('parseErrorCode', () => {
  const cases: Array<[unknown, string]> = [
    [{ code: 'PIN_NOT_FOUND' }, 'PIN_NOT_FOUND'],
    [{ code: 'ALTERNANZA_VIOLATA' }, 'ALTERNANZA_VIOLATA'],
    [{ code: 'RATE_LIMIT' }, 'RATE_LIMIT'],
    [new Error('network error'), 'NETWORK'],
    [null, 'UNKNOWN'],
  ]
  for (const [input, out] of cases) {
    it(`maps ${JSON.stringify(input)} -> ${out}`, () => {
      expect(parseErrorCode(input as any)).toBe(out as any)
    })
  }
})
