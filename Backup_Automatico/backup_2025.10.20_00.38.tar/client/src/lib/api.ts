// client/src/lib/api.ts
export function getApiBaseUrl(): string {
  const fromEnv = (import.meta as any)?.env?.VITE_API_BASE_URL?.toString().trim();
  const fallback = `${window.location.origin}`; // useful behind reverse proxy in prod
  const base = fromEnv || fallback;

  // Diagnostics in browser devtools
  if (typeof window !== 'undefined') {
    (window as any).__BADGENODE__ = (window as any).__BADGENODE__ || {};
    (window as any).__BADGENODE__.api = { base, fromEnv: !!fromEnv };
  }

  return base.replace(/\/+$/, '');
}
