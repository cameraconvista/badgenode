// Re-export from adapter to maintain compatibility
export { subscribeTimbrature } from '@/adapters/realtimeAdapter';
